﻿namespace KNN
{
    public enum Metrics
    {
        Euclidean,
        Manhattan
    }
}
